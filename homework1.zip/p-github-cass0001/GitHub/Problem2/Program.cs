﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> Students = new Dictionary<int, string>();

            //Adding to the dictionary (Key has to be unique)
            Students.Add(1234567, "Marcus Cassar");

            //Checking if key exists
            if (Students.ContainsKey(1234567))
            {
                Console.WriteLine($"{1234567} already exists");
            }
            else
            {
                Console.WriteLine("Key does not exist");
            }

            //Getting a value
            Console.WriteLine(Students[1234567]);
            
            Console.ReadKey();
        }
    }
}
