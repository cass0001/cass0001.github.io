﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections___Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> fruits = new Dictionary<string, string>();

            fruits.Add("Apples", "0.99");
            fruits.Add("Oranges", "0.50");
            fruits.Add("Bananas", "0.50");
            fruits.Add("Grapes", "2.99");
            fruits.Add("Blueberries", "1.99");

            string name;
            Console.WriteLine("Fruit: ");
            name = Console.ReadLine();

            if (fruits.ContainsKey(name))
            {
                Console.WriteLine($"The {name} cost $" + (fruits[name]));
            }
            else
            {
                Console.WriteLine("Fruit not found");
            }

            Console.ReadKey();
        }
    }
}
