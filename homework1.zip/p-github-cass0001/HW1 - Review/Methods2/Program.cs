﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;

            Console.WriteLine("Number: ");
            num = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("The factorial is {0}", Factorial(num));
            Console.ReadKey();
        }
        
        public static int Factorial(int Rnumber)
        {
            for (int i = Rnumber - 1; i >= 1; i--) 
            {
                Rnumber = Rnumber * i;
            }
            return Rnumber;
        }
    }
}
