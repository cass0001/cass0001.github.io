﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW1___Review
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] item = { "apples", "oranges", "bananas", "grapes", "blueberries" };
            string[] price = { "0.99", "0.50", "0.50", "2.99", "1.99" };

            string selection, cost = "";

            Console.Write("Please enter item: ");
            selection = Console.ReadLine();
            int index;

            if(item[0]==selection)
            {
                Console.WriteLine($"The price is ${price[0]}");
            }
            else if (item[1]==selection)
            {
                Console.WriteLine($"The price is ${price[1]}");
            }
            else if (item[2] == selection)
            {
                Console.WriteLine($"The price is ${price[2]}");
            }
            else if (item[3] == selection)
            {
                Console.WriteLine($"The price is {price[3]}");
            }
            else if (item[4] == selection)
            {
                Console.WriteLine($"The price is {price[4]}");
            }
            
            Console.ReadKey();
        }
    }
}
