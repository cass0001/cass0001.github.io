﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections___List
{
    class Program
    {
        static void Main(string[] args)
        {
            List<double> exams = new List<double>();

            double response;
            Console.WriteLine("Enter exam score (Press 0 if finished): ");

            do
            {
                response = Convert.ToDouble(Console.ReadLine());
                if (response == 0)
                {
                    Console.WriteLine($"The exam average is {exams.Average()}%");
                }
                else
                {
                    exams.Add(response);
                }
            } while (response != 0);

            Console.ReadKey();
        }
    }
}
