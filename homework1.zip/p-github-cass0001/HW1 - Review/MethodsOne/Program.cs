﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsOne
{
    class Program
    {
        static void Main(string[] args)
        {
            int m = 0;
            int x = 0;
            int b = 0;
                 //jjjj
            Console.WriteLine("M:");
            m = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("X: ");
            x = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("B: ");
            b = Convert.ToInt32(Console.ReadLine());

            int answer = LineValueForY(m, x, b);

            Console.WriteLine("Y={0}", LineValueForY(m, x, b));

            Console.ReadKey();

        }

        private static int LineValueForY(int param, int parax, int parab)
        {
            int Y = (param * parax) + parab;
            return Y;
        }
    }
}
