﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Methods1
{
    class Program
    {
        static void Main(string[] args)
        {
            double m = 0;
            double x = 0;
            double b = 0;

            Console.WriteLine("M:");
            m = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("X: ");
            x = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("B: ");
            b = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Y={0}", LineValueForY(m, x, b));

            Console.ReadKey();
       
        }

        private static int LineValueForY(double param, double parax, double parab)
        {
            double Y = (param *parax) + parab;
            return Y;
        }
    }
}
