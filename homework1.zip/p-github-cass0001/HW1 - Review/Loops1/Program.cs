﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, n, sum = 0;
            double AverageScore;

            Console.WriteLine("Please enter your 3 exam grades");

            for (i = 1; i <= 3; i++)
            {
                Console.WriteLine($"Exam {i}: ", i);
                n = Convert.ToInt32(Console.ReadLine());
                sum += n;
            }

            AverageScore = sum / 3;

            Console.WriteLine($"The average exam score is: {AverageScore}%");

            Console.ReadKey();
        }
    }
}
