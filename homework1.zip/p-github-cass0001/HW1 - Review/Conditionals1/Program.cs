﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conditionals1
{
    class Program
    {
        static void Main(string[] args)
        {
            const double CogPrice = 79.99;
            const double GearPrice = 250;
            const double SalesTax = 0.089;
            const double StandardMarkup = 1.15;
            const double BulkMarkup = 1.25;
            const double Discount = (1.25 - 1.15);

            int CogAmount;
            int GearAmount;

            Console.WriteLine("Amount of cogs: ");
            CogAmount = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Amount of gears: ");
            GearAmount = Convert.ToInt32(Console.ReadLine());

            double TotalPriceBulk;
            double TotalPriceStandard;
            double InitialPrice;
            double TaxAmount;
            double MarkupBulk;
            double MarkupStandard;
            double DiscountAmount;

            InitialPrice = ((CogPrice * CogAmount) + (GearAmount * GearPrice));
            TaxAmount = InitialPrice * SalesTax;
            MarkupBulk = InitialPrice * (BulkMarkup - 1);
            MarkupStandard = InitialPrice * (StandardMarkup - 1);
            DiscountAmount = InitialPrice * (Discount);
            TotalPriceBulk = (InitialPrice * BulkMarkup) + TaxAmount;
            TotalPriceStandard = (InitialPrice * StandardMarkup) + TaxAmount;

            if (CogAmount >= 10 || GearAmount >= 10 || (CogAmount + GearAmount) >= 16)
            {

                Console.WriteLine("Qualified for bulk discount");
                Console.WriteLine($"SalePrice: {InitialPrice:C}");
                Console.WriteLine($"Tax: {TaxAmount:C}");
                Console.WriteLine($"Markup: {MarkupBulk:C}");
                Console.WriteLine($"TOTAL: {TotalPriceBulk:C}");
                Console.WriteLine($"Saved: {DiscountAmount:C}");
            }
            else
            {
                Console.WriteLine("Did not qualify for bulk discount");
                Console.WriteLine($"SalePrice: {InitialPrice:C}");
                Console.WriteLine($"Tax: {TaxAmount:C}");
                Console.WriteLine($"Markup: {MarkupStandard:C}");
                Console.WriteLine($"TOTAL: {TotalPriceStandard:C}");
            }

            Console.ReadKey();
        }
    }
}
