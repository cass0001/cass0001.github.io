﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops2
{
    class Program
    {
        static void Main(string[] args)
        {
            double score;
            int exams = 0;
            double cumulativeScore = 0;
            string response;
            double averageScore;

            do
            {
                Console.WriteLine("Exam Score: ");
                score = Convert.ToDouble(Console.ReadLine());
                cumulativeScore = cumulativeScore + score;
                Console.WriteLine("Do you have another score (Yes/No)?");
                response = Console.ReadLine();
                exams++;
            } while (response.ToLower() == "Yes");

            averageScore = cumulativeScore / exams;
            Console.WriteLine($"Average exam score: {averageScore}");

            Console.ReadKey();
        }
    }
}
