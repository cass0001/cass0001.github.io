﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays2
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] lowercaseLetters = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            char[] uppercaseLetters = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };

            Console.WriteLine($"{uppercaseLetters[12]}{lowercaseLetters[0]}{lowercaseLetters[17]}{lowercaseLetters[2]}{lowercaseLetters[20]}{lowercaseLetters[18]} {uppercaseLetters[2]}{lowercaseLetters[0]}{lowercaseLetters[18]}{lowercaseLetters[18]}{lowercaseLetters[0]}{lowercaseLetters[17]}");

            Console.ReadKey();
        }
    }
}
