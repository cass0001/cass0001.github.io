﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0828_3013Review
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
        static double Add(int num1, double num2)
        {
            double result = num1 + num2;
            return result;
        }
    }
}
